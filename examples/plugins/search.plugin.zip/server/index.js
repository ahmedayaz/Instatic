(() => {
  var __defProp = Object.defineProperty;
  var __returnValue = (v) => v;
  function __exportSetter(name, newValue) {
    this[name] = __returnValue.bind(null, newValue);
  }
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, {
        get: all[name],
        enumerable: true,
        configurable: true,
        set: __exportSetter.bind(all, name)
      });
  };

  // examples/plugins/search/server/index.ts
  var exports_server = {};
  __export(exports_server, {
    default: () => server_default
  });

  // examples/plugins/search/server/backends/meilisearch.ts
  function isMeiliSearchResponse(v) {
    if (typeof v !== "object" || v === null)
      return false;
    const obj = v;
    return Array.isArray(obj.hits) && typeof obj.processingTimeMs === "number";
  }
  function isMeiliStatsResponse(v) {
    if (typeof v !== "object" || v === null)
      return false;
    return typeof v.numberOfDocuments === "number";
  }
  function createMeiliSearchBackend(opts) {
    const { endpoint, adminApiKey, searchApiKey, indexName, searchableFields, excerptLength } = opts;
    const base = endpoint.replace(/\/$/, "");
    const indexUrl = `${base}/indexes/${encodeURIComponent(indexName)}`;
    function adminHeaders() {
      return {
        Authorization: `Bearer ${adminApiKey}`,
        "Content-Type": "application/json"
      };
    }
    function searchHeaders() {
      return {
        Authorization: `Bearer ${searchApiKey}`,
        "Content-Type": "application/json"
      };
    }
    async function ensureIndex() {
      const createRes = await fetch(`${base}/indexes`, {
        method: "POST",
        headers: adminHeaders(),
        body: JSON.stringify({ uid: indexName, primaryKey: "id" }),
        signal: AbortSignal.timeout(1e4)
      });
      if (!createRes.ok) {
        const body = await createRes.json();
        const code = String(body.code ?? "");
        if (code !== "index_already_exists") {
          throw new Error(`MeiliSearch: failed to create index "${indexName}": ${body.message ?? createRes.status}`);
        }
      }
      const settingsRes = await fetch(`${indexUrl}/settings/searchable-attributes`, {
        method: "PUT",
        headers: adminHeaders(),
        body: JSON.stringify(searchableFields),
        signal: AbortSignal.timeout(1e4)
      });
      if (!settingsRes.ok) {
        const body = await settingsRes.json();
        throw new Error(`MeiliSearch: failed to update searchable attributes: ${body.message ?? settingsRes.status}`);
      }
    }
    async function upsertDocuments(docs) {
      if (docs.length === 0)
        return;
      const res = await fetch(`${indexUrl}/documents`, {
        method: "POST",
        headers: adminHeaders(),
        body: JSON.stringify(docs),
        signal: AbortSignal.timeout(30000)
      });
      if (!res.ok) {
        const body = await res.json();
        throw new Error(`MeiliSearch: upsert failed: ${body.message ?? res.status}`);
      }
    }
    async function deleteDocument(id) {
      const res = await fetch(`${indexUrl}/documents/${encodeURIComponent(id)}`, {
        method: "DELETE",
        headers: adminHeaders(),
        signal: AbortSignal.timeout(1e4)
      });
      if (!res.ok && res.status !== 404) {
        const body = await res.json();
        throw new Error(`MeiliSearch: delete failed: ${body.message ?? res.status}`);
      }
    }
    async function search(query, { page, perPage }) {
      const started = Date.now();
      const offset = (page - 1) * perPage;
      const res = await fetch(`${indexUrl}/search`, {
        method: "POST",
        headers: searchHeaders(),
        body: JSON.stringify({
          q: query,
          limit: perPage,
          offset,
          attributesToRetrieve: ["id", "slug", "title", "excerpt"],
          attributesToHighlight: [],
          attributesToCrop: ["excerpt"],
          cropLength: Math.ceil(excerptLength / 5)
        }),
        signal: AbortSignal.timeout(1e4)
      });
      if (!res.ok) {
        const body2 = await res.json();
        throw new Error(`MeiliSearch: search failed: ${body2.message ?? res.status}`);
      }
      const body = await res.json();
      if (!isMeiliSearchResponse(body)) {
        throw new Error("MeiliSearch: unexpected search response shape");
      }
      const total = body.totalHits ?? body.estimatedTotalHits ?? body.hits.length;
      const hits = body.hits.map((h) => ({
        id: String(h.id),
        slug: String(h.slug ?? ""),
        title: String(h.title ?? ""),
        excerpt: String(h.excerpt ?? "").slice(0, excerptLength)
      }));
      return {
        hits,
        total,
        tookMs: Date.now() - started
      };
    }
    async function clearIndex() {
      const res = await fetch(`${indexUrl}/documents`, {
        method: "DELETE",
        headers: adminHeaders(),
        signal: AbortSignal.timeout(1e4)
      });
      if (!res.ok && res.status !== 404) {
        const body = await res.json();
        throw new Error(`MeiliSearch: clear index failed: ${body.message ?? res.status}`);
      }
    }
    async function getStats() {
      const res = await fetch(`${indexUrl}/stats`, {
        method: "GET",
        headers: adminHeaders(),
        signal: AbortSignal.timeout(1e4)
      });
      let docCount = 0;
      let sizeBytes = null;
      if (res.ok) {
        const body = await res.json();
        if (isMeiliStatsResponse(body)) {
          docCount = body.numberOfDocuments;
          sizeBytes = typeof body.rawDocumentDbSize === "number" ? body.rawDocumentDbSize : null;
        }
      } else if (res.status !== 404) {
        const body = await res.json();
        throw new Error(`MeiliSearch: stats failed: ${body.message ?? res.status}`);
      }
      let endpointHost = endpoint;
      try {
        endpointHost = new URL(endpoint).host;
      } catch (_err) {}
      return {
        docCount,
        sizeBytes,
        lastSyncedAt: null,
        backend: "meilisearch",
        endpointHost
      };
    }
    return {
      ensureIndex,
      upsertDocuments,
      deleteDocument,
      search,
      clearIndex,
      getStats
    };
  }

  // examples/plugins/search/server/backends/typesense.ts
  function isTypesenseSearchResponse(v) {
    if (typeof v !== "object" || v === null)
      return false;
    const obj = v;
    return typeof obj.found === "number" && typeof obj.search_time_ms === "number";
  }
  function isTypesenseCollectionInfo(v) {
    if (typeof v !== "object" || v === null)
      return false;
    const obj = v;
    return typeof obj.name === "string" && typeof obj.num_documents === "number";
  }
  function createTypesenseBackend(opts) {
    const { endpoint, adminApiKey, searchApiKey, indexName, searchableFields, excerptLength } = opts;
    const base = endpoint.replace(/\/$/, "");
    const collectionUrl = `${base}/collections/${encodeURIComponent(indexName)}`;
    function adminHeaders() {
      return {
        "X-TYPESENSE-API-KEY": adminApiKey,
        "Content-Type": "application/json"
      };
    }
    function searchHeaders() {
      return {
        "X-TYPESENSE-API-KEY": searchApiKey,
        "Content-Type": "application/json"
      };
    }
    async function ensureIndex() {
      const checkRes = await fetch(collectionUrl, {
        method: "GET",
        headers: adminHeaders(),
        signal: AbortSignal.timeout(1e4)
      });
      if (checkRes.ok) {
        return;
      }
      if (checkRes.status !== 404) {
        const body = await checkRes.json();
        throw new Error(`Typesense: could not check collection: ${body.message ?? checkRes.status}`);
      }
      const fields = [
        { name: "id", type: "string" },
        { name: "slug", type: "string", index: false },
        { name: "title", type: "string" },
        { name: "headings", type: "string", optional: true },
        { name: "content", type: "string", optional: true },
        { name: "excerpt", type: "string", optional: true },
        { name: "indexedAt", type: "string", index: false, optional: true }
      ];
      const schema = {
        name: indexName,
        fields
      };
      const createRes = await fetch(`${base}/collections`, {
        method: "POST",
        headers: adminHeaders(),
        body: JSON.stringify(schema),
        signal: AbortSignal.timeout(1e4)
      });
      if (!createRes.ok) {
        const body = await createRes.json();
        if (String(body.message ?? "").includes("already exists"))
          return;
        throw new Error(`Typesense: failed to create collection "${indexName}": ${body.message ?? createRes.status}`);
      }
    }
    async function upsertDocuments(docs) {
      if (docs.length === 0)
        return;
      const jsonl = docs.map((d) => JSON.stringify(d)).join(`
`);
      const res = await fetch(`${collectionUrl}/documents/import?action=upsert`, {
        method: "POST",
        headers: {
          "X-TYPESENSE-API-KEY": adminApiKey,
          "Content-Type": "text/plain"
        },
        body: jsonl,
        signal: AbortSignal.timeout(30000)
      });
      if (!res.ok) {
        const text = await res.text();
        throw new Error(`Typesense: import failed (${res.status}): ${text.slice(0, 200)}`);
      }
    }
    async function deleteDocument(id) {
      const res = await fetch(`${collectionUrl}/documents/${encodeURIComponent(id)}`, {
        method: "DELETE",
        headers: adminHeaders(),
        signal: AbortSignal.timeout(1e4)
      });
      if (!res.ok && res.status !== 404) {
        const body = await res.json();
        throw new Error(`Typesense: delete failed: ${body.message ?? res.status}`);
      }
    }
    async function search(query, { page, perPage }) {
      const started = Date.now();
      const queryFields = searchableFields.join(",");
      const params = new URLSearchParams({
        q: query,
        query_by: queryFields || "title,headings,content",
        per_page: String(perPage),
        page: String(page),
        include_fields: "id,slug,title,excerpt",
        highlight_fields: "none"
      });
      const res = await fetch(`${collectionUrl}/documents/search?${params.toString()}`, {
        method: "GET",
        headers: searchHeaders(),
        signal: AbortSignal.timeout(1e4)
      });
      if (!res.ok) {
        const body2 = await res.json();
        throw new Error(`Typesense: search failed: ${body2.message ?? res.status}`);
      }
      const body = await res.json();
      if (!isTypesenseSearchResponse(body)) {
        throw new Error("Typesense: unexpected search response shape");
      }
      const hits = (body.hits ?? []).map((h) => ({
        id: String(h.document.id ?? ""),
        slug: String(h.document.slug ?? ""),
        title: String(h.document.title ?? ""),
        excerpt: String(h.document.excerpt ?? "").slice(0, excerptLength)
      }));
      return {
        hits,
        total: body.found,
        tookMs: Date.now() - started
      };
    }
    async function clearIndex() {
      const res = await fetch(`${collectionUrl}/documents?filter_by=id:!=__none__`, {
        method: "DELETE",
        headers: adminHeaders(),
        signal: AbortSignal.timeout(30000)
      });
      if (!res.ok && res.status !== 404) {
        const body = await res.json();
        throw new Error(`Typesense: clear failed: ${body.message ?? res.status}`);
      }
    }
    async function getStats() {
      const res = await fetch(collectionUrl, {
        method: "GET",
        headers: adminHeaders(),
        signal: AbortSignal.timeout(1e4)
      });
      let docCount = 0;
      if (res.ok) {
        const body = await res.json();
        if (isTypesenseCollectionInfo(body)) {
          docCount = body.num_documents;
        }
      } else if (res.status !== 404) {
        const body = await res.json();
        throw new Error(`Typesense: stats failed: ${body.message ?? res.status}`);
      }
      let endpointHost = endpoint;
      try {
        endpointHost = new URL(endpoint).host;
      } catch (_err) {}
      return {
        docCount,
        sizeBytes: null,
        lastSyncedAt: null,
        backend: "typesense",
        endpointHost
      };
    }
    return {
      ensureIndex,
      upsertDocuments,
      deleteDocument,
      search,
      clearIndex,
      getStats
    };
  }

  // examples/plugins/search/server/extract.ts
  var NAMED_ENTITIES = {
    amp: "&",
    lt: "<",
    gt: ">",
    quot: '"',
    apos: "'",
    nbsp: " ",
    mdash: "—",
    ndash: "–",
    lsquo: "‘",
    rsquo: "’",
    ldquo: "“",
    rdquo: "”",
    hellip: "…",
    copy: "©",
    reg: "®",
    trade: "™"
  };
  function decodeEntities(s) {
    return s.replace(/&(#(\d+)|#x([\da-fA-F]+)|([a-zA-Z]+));/g, (_m, _full, dec, hex, named) => {
      if (dec)
        return String.fromCodePoint(parseInt(dec, 10));
      if (hex)
        return String.fromCodePoint(parseInt(hex, 16));
      if (named)
        return NAMED_ENTITIES[named.toLowerCase()] ?? _m;
      return _m;
    });
  }
  function lc(s) {
    return s.toLowerCase();
  }
  function tagName(token) {
    const start = token[1] === "/" ? 2 : 1;
    let end = start;
    while (end < token.length && !/[\s>]/.test(token[end]))
      end++;
    return lc(token.slice(start, end));
  }
  function isClosing(token) {
    return token[1] === "/";
  }
  function* tokenise(html) {
    let i = 0;
    const len = html.length;
    while (i < len) {
      if (html[i] === "<") {
        if (html.startsWith("<!--", i)) {
          const end = html.indexOf("-->", i + 4);
          if (end === -1)
            break;
          yield html.slice(i, end + 3);
          i = end + 3;
          continue;
        }
        let j = i + 1;
        let inAttrDq = false;
        let inAttrSq = false;
        while (j < len) {
          const ch = html[j];
          if (!inAttrDq && !inAttrSq) {
            if (ch === '"') {
              inAttrDq = true;
              j++;
              continue;
            }
            if (ch === "'") {
              inAttrSq = true;
              j++;
              continue;
            }
            if (ch === ">") {
              j++;
              break;
            }
          } else if (inAttrDq && ch === '"') {
            inAttrDq = false;
          } else if (inAttrSq && ch === "'") {
            inAttrSq = false;
          }
          j++;
        }
        yield html.slice(i, j);
        i = j;
      } else {
        const j = html.indexOf("<", i);
        if (j === -1) {
          yield html.slice(i);
          break;
        }
        yield html.slice(i, j);
        i = j;
      }
    }
  }
  function extractState(html) {
    const st = {
      title: "",
      headings: [],
      bodyParts: [],
      inSkipBlock: false,
      inHeading: false,
      inTitle: false,
      headingLevel: 0,
      headingBuf: "",
      titleBuf: ""
    };
    for (const token of tokenise(html)) {
      if (token.startsWith("<!--"))
        continue;
      if (!token.startsWith("<")) {
        if (st.inSkipBlock)
          continue;
        const decoded = decodeEntities(token).replace(/\s+/g, " ").trim();
        if (!decoded)
          continue;
        if (st.inTitle) {
          st.titleBuf += (st.titleBuf ? " " : "") + decoded;
          continue;
        }
        if (st.inHeading) {
          st.headingBuf += (st.headingBuf ? " " : "") + decoded;
          continue;
        }
        st.bodyParts.push(decoded);
        continue;
      }
      const name = tagName(token);
      const closing = isClosing(token);
      if (!closing && (name === "script" || name === "style" || name === "noscript")) {
        st.inSkipBlock = true;
        continue;
      }
      if (closing && (name === "script" || name === "style" || name === "noscript")) {
        st.inSkipBlock = false;
        continue;
      }
      if (st.inSkipBlock)
        continue;
      if (!closing && name === "title") {
        st.inTitle = true;
        continue;
      }
      if (closing && name === "title") {
        st.title = st.titleBuf.trim();
        st.titleBuf = "";
        st.inTitle = false;
        continue;
      }
      const hMatch = /^h([1-4])$/.exec(name);
      if (hMatch) {
        const level = parseInt(hMatch[1], 10);
        if (!closing) {
          st.inHeading = true;
          st.headingLevel = level;
          st.headingBuf = "";
        } else if (st.inHeading && st.headingLevel === level) {
          if (st.headingBuf)
            st.headings.push(st.headingBuf.trim());
          st.headingBuf = "";
          st.inHeading = false;
          st.headingLevel = 0;
        }
        continue;
      }
    }
    return st;
  }
  function extractSearchDoc(html, meta, excerptLen) {
    const st = extractState(html);
    const title = st.title || st.headings[0] || meta.slug;
    const headings = st.headings.join(" ");
    const content = st.bodyParts.join(" ");
    const rawExcerpt = content.slice(0, excerptLen * 2);
    const excerpt = rawExcerpt.length > excerptLen ? rawExcerpt.slice(0, excerptLen).replace(/\s+\S*$/, "") + "…" : rawExcerpt;
    return {
      id: meta.id,
      slug: meta.slug,
      title,
      headings,
      content,
      excerpt,
      indexedAt: new Date().toISOString()
    };
  }

  // examples/plugins/search/server/rateLimit.ts
  function djb2Hash(s) {
    let hash = 5381;
    for (let i = 0;i < s.length; i++) {
      hash = (hash << 5) + hash ^ s.charCodeAt(i);
    }
    return hash >>> 0;
  }
  var WINDOW_MS = 60000;
  function createRateLimiter(opts = {}) {
    const max = opts.maxPerMinute ?? 60;
    const buckets = new Map;
    let lastPruneAt = Date.now();
    function prune(now) {
      if (now - lastPruneAt < WINDOW_MS)
        return;
      lastPruneAt = now;
      for (const [key, bucket] of buckets) {
        if (now - bucket.windowStart >= WINDOW_MS * 2) {
          buckets.delete(key);
        }
      }
    }
    function check(ip) {
      const now = Date.now();
      prune(now);
      const key = djb2Hash(ip);
      const existing = buckets.get(key);
      if (!existing || now - existing.windowStart >= WINDOW_MS) {
        buckets.set(key, { count: 1, windowStart: now });
        return { limited: false, retryAfterSeconds: 0 };
      }
      existing.count++;
      if (existing.count > max) {
        const windowEndsAt = existing.windowStart + WINDOW_MS;
        const retryAfterSeconds = Math.ceil((windowEndsAt - now) / 1000);
        return { limited: true, retryAfterSeconds: Math.max(1, retryAfterSeconds) };
      }
      return { limited: false, retryAfterSeconds: 0 };
    }
    return { check };
  }

  // examples/plugins/search/server/analytics.ts
  function isQueryRecord(v) {
    if (typeof v !== "object" || v === null)
      return false;
    const obj = v;
    return typeof obj.query === "string" && typeof obj["searched-at"] === "string";
  }
  async function logQuery(api, query, resultCount, tookMs) {
    try {
      await api.cms.storage.collection("queries").create({
        query,
        "result-count": resultCount,
        "took-ms": tookMs,
        "searched-at": new Date().toISOString()
      });
    } catch (_err) {}
  }
  async function getAnalyticsSnapshot(api) {
    const all = await api.cms.storage.collection("queries").list();
    const cutoff = Date.now() - 7 * 24 * 60 * 60 * 1000;
    const recent = all.filter((r) => {
      const record = r.data;
      if (!isQueryRecord(record))
        return false;
      return new Date(record["searched-at"]).getTime() >= cutoff;
    });
    const byQuery = new Map;
    for (const r of recent) {
      const record = r.data;
      const key = record.query.trim().toLowerCase();
      if (!key)
        continue;
      const existing = byQuery.get(key) ?? { count: 0, resultTotal: 0, noResults: 0 };
      existing.count++;
      const rc = typeof record["result-count"] === "number" ? record["result-count"] : 0;
      existing.resultTotal += rc;
      if (rc === 0)
        existing.noResults++;
      byQuery.set(key, existing);
    }
    const sorted = Array.from(byQuery.entries()).sort((a, b) => b[1].count - a[1].count);
    const topQueries = sorted.slice(0, 10).map(([q, s]) => ({
      query: q,
      count: s.count,
      avgResultCount: s.count > 0 ? Math.round(s.resultTotal / s.count) : 0
    }));
    const topNoResults = sorted.filter(([, s]) => s.noResults > 0).sort((a, b) => b[1].noResults - a[1].noResults).slice(0, 10).map(([q, s]) => ({
      query: q,
      count: s.noResults,
      avgResultCount: 0
    }));
    return { topQueries, topNoResults };
  }

  // examples/plugins/search/server/searchRoute.ts
  function clampInt(raw, min, max, def) {
    if (raw === null)
      return def;
    const n = parseInt(raw, 10);
    if (Number.isNaN(n))
      return def;
    return Math.max(min, Math.min(max, n));
  }
  function sanitiseQuery(raw) {
    if (!raw)
      return "";
    return raw.trim().slice(0, 200);
  }
  function buildSearchRouteHandler(opts) {
    const { backend, limiter, api } = opts;
    return async function handleSearch(ctx) {
      const ip = ctx.req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ?? ctx.req.headers.get("x-real-ip") ?? "unknown";
      const rl = limiter.check(ip);
      if (rl.limited) {
        return new Response(JSON.stringify({ error: "Too many requests", retry_after: rl.retryAfterSeconds }), {
          status: 429,
          headers: {
            "Content-Type": "application/json",
            "Retry-After": String(rl.retryAfterSeconds),
            "Cache-Control": "no-store"
          }
        });
      }
      const url = new URL(ctx.req.url);
      const q = sanitiseQuery(url.searchParams.get("q"));
      const page = clampInt(url.searchParams.get("page"), 1, 1000, 1);
      const perPage = clampInt(url.searchParams.get("per-page"), 1, 50, 10);
      if (!q) {
        return new Response(JSON.stringify({ results: [], total: 0, took_ms: 0, query: "" }), {
          status: 200,
          headers: { "Content-Type": "application/json", "Cache-Control": "public, max-age=10" }
        });
      }
      let results;
      try {
        results = await backend.search(q, { page, perPage });
      } catch (err) {
        const message = err instanceof Error ? err.message : "Search failed";
        api.plugin.log("[search route] backend error:", message);
        return new Response(JSON.stringify({ error: "Search service unavailable" }), {
          status: 503,
          headers: { "Content-Type": "application/json", "Cache-Control": "no-store" }
        });
      }
      const enableLogging = api.cms.settings.get("enableQueryLogging") ?? true;
      if (enableLogging) {
        logQuery(api, q, results.total, results.tookMs);
      }
      const body = JSON.stringify({
        results: results.hits,
        total: results.total,
        took_ms: results.tookMs,
        query: q
      });
      return new Response(body, {
        status: 200,
        headers: {
          "Content-Type": "application/json",
          "Cache-Control": "public, max-age=10"
        }
      });
    };
  }

  // examples/plugins/search/server/index.ts
  function readBackendOptions(api) {
    const endpoint = api.cms.settings.get("endpoint") ?? "";
    const adminApiKey = api.cms.settings.get("adminApiKey") ?? "";
    const searchApiKey = api.cms.settings.get("searchApiKey") ?? "";
    const indexName = api.cms.settings.get("indexName") ?? "pagebuilder";
    const searchableFieldsRaw = api.cms.settings.get("searchableFields") ?? `title
headings
content`;
    const excerptLength = Number(api.cms.settings.get("excerptLength") ?? 200);
    if (!endpoint || !adminApiKey) {
      api.plugin.log("Search plugin: endpoint and adminApiKey must be configured in Settings.");
      return null;
    }
    const searchableFields = searchableFieldsRaw.split(`
`).map((s) => s.trim()).filter(Boolean);
    return {
      endpoint,
      adminApiKey,
      searchApiKey: searchApiKey || adminApiKey,
      indexName,
      searchableFields,
      excerptLength
    };
  }
  function pickBackend(api, opts) {
    const backend = api.cms.settings.get("backend") ?? "meilisearch";
    return backend === "typesense" ? createTypesenseBackend(opts) : createMeiliSearchBackend(opts);
  }
  function parseExcludePaths(api) {
    const raw = api.cms.settings.get("excludePaths") ?? "";
    return raw.split(`
`).map((s) => s.trim()).filter(Boolean);
  }
  function isExcluded(slug, excludePaths) {
    return excludePaths.some((p) => slug.startsWith(p));
  }
  function slugToDocId(slug) {
    return slug.replace(/^\//, "").replace(/\//g, "_") || "root";
  }
  function pageIdToSlug(pageId) {
    return pageId.startsWith("/") ? pageId : `/${pageId}`;
  }
  var mod = {
    install(api) {
      api.plugin.log("Search plugin installed — configure endpoint + API keys in Settings.");
    },
    async activate(api) {
      api.plugin.log("Search plugin activating");
      const opts = readBackendOptions(api);
      const limiter = createRateLimiter({ maxPerMinute: 60 });
      let backend = null;
      if (opts) {
        try {
          backend = pickBackend(api, opts);
          await backend.ensureIndex();
          api.plugin.log("Search plugin: index ready");
        } catch (err) {
          const message = err instanceof Error ? err.message : String(err);
          api.plugin.log("Search plugin: ensureIndex failed:", message);
          backend = null;
        }
      }
      if (backend) {
        const searchHandler = buildSearchRouteHandler({ backend, limiter, api });
        api.cms.routes.getPublic("/search", searchHandler);
      } else {
        api.cms.routes.getPublic("/search", async () => {
          return new Response(JSON.stringify({ error: "Search is not configured. Set endpoint and API keys in plugin Settings." }), { status: 503, headers: { "Content-Type": "application/json", "Cache-Control": "no-store" } });
        });
      }
      api.cms.routes.get("/admin-search", "plugins.manage", async (ctx) => {
        if (!backend) {
          return new Response(JSON.stringify({ error: "Backend not configured." }), { status: 503, headers: { "Content-Type": "application/json" } });
        }
        const url = new URL(ctx.req.url);
        const q = (url.searchParams.get("q") ?? "").trim().slice(0, 200);
        const perPage = Math.max(1, Math.min(50, parseInt(url.searchParams.get("per-page") ?? "20", 10) || 20));
        if (!q) {
          return { results: [], total: 0, took_ms: 0, query: "" };
        }
        try {
          const liveOpts = readBackendOptions(api);
          const liveBackend = liveOpts ? pickBackend(api, liveOpts) : backend;
          const results = await liveBackend.search(q, { page: 1, perPage });
          return {
            results: results.hits,
            total: results.total,
            took_ms: results.tookMs,
            query: q
          };
        } catch (err) {
          const message = err instanceof Error ? err.message : String(err);
          return new Response(JSON.stringify({ error: message }), { status: 503, headers: { "Content-Type": "application/json" } });
        }
      });
      api.cms.routes.get("/status", "plugins.manage", async () => {
        if (!backend) {
          const currentOpts = readBackendOptions(api);
          return {
            ok: false,
            configured: false,
            message: currentOpts === null ? "endpoint and adminApiKey must be set in plugin Settings." : "Backend failed to initialise — check plugin logs."
          };
        }
        try {
          const liveOpts = readBackendOptions(api);
          const liveBackend = liveOpts ? pickBackend(api, liveOpts) : backend;
          const stats = await liveBackend.getStats();
          return { ok: true, configured: true, stats };
        } catch (err) {
          const message = err instanceof Error ? err.message : String(err);
          return { ok: false, configured: true, message };
        }
      });
      api.cms.routes.get("/analytics", "plugins.manage", async () => {
        const enableLogging = api.cms.settings.get("enableQueryLogging") ?? true;
        if (!enableLogging) {
          return { ok: true, loggingDisabled: true, topQueries: [], topNoResults: [] };
        }
        const snapshot = await getAnalyticsSnapshot(api);
        return { ok: true, ...snapshot };
      });
      api.cms.routes.post("/clear", "plugins.manage", async () => {
        if (!backend) {
          return { ok: false, message: "Backend not configured." };
        }
        try {
          const liveOpts = readBackendOptions(api);
          const liveBackend = liveOpts ? pickBackend(api, liveOpts) : backend;
          await liveBackend.clearIndex();
          return { ok: true, message: "Index cleared." };
        } catch (err) {
          const message = err instanceof Error ? err.message : String(err);
          return { ok: false, message };
        }
      });
      const pendingPublish = new Map;
      api.cms.hooks.on("publish.before", async (evt) => {
        if (!evt.pageId)
          return;
        const slug = pageIdToSlug(evt.pageId);
        pendingPublish.set(evt.siteId, { slug });
      });
      api.cms.hooks.filter("publish.html", async (html, _ctx) => {
        if (!backend || typeof html !== "string")
          return html;
        const entries = Array.from(pendingPublish.entries());
        if (entries.length === 0)
          return html;
        const [siteId, { slug }] = entries[0];
        const excludePaths = parseExcludePaths(api);
        if (isExcluded(slug, excludePaths)) {
          api.plugin.log(`Search plugin: skipping excluded slug "${slug}"`);
          return html;
        }
        const excerptLength = Number(api.cms.settings.get("excerptLength") ?? 200);
        const docId = slugToDocId(slug);
        const doc = extractSearchDoc(html, { id: docId, slug }, excerptLength);
        try {
          const liveOpts = readBackendOptions(api);
          const liveBackend = liveOpts ? pickBackend(api, liveOpts) : backend;
          await liveBackend.upsertDocuments([doc]);
          api.plugin.log(`Search plugin: indexed "${slug}" (${docId})`);
        } catch (err) {
          const message = err instanceof Error ? err.message : String(err);
          api.plugin.log("Search plugin: upsert failed:", message);
        }
        pendingPublish.delete(siteId);
        return html;
      });
      api.cms.hooks.on("publish.after", async (evt) => {
        if (evt.siteId)
          pendingPublish.delete(evt.siteId);
      });
      api.plugin.log("Search plugin activated.");
    },
    deactivate(api) {
      api.plugin.log("Search plugin deactivated.");
    },
    async uninstall(api) {
      const queries = api.cms.storage.collection("queries");
      const all = await queries.list();
      await Promise.all(all.map((r) => queries.delete(r.id)));
      api.plugin.log(`Search plugin uninstalled, removed ${all.length} query log entries.`);
    }
  };
  var server_default = mod;

  // examples/plugins/search/server/__sandbox-facade-1779267229210.ts
  var __default = exports_server && server_default;
  var __isPluginModule = (v) => v && typeof v === "object" && (typeof v.install === "function" || typeof v.activate === "function" || typeof v.deactivate === "function" || typeof v.uninstall === "function" || typeof v.migrate === "function");
  globalThis.__plugin_exports = __isPluginModule(__default) ? __default : exports_server;
})();
