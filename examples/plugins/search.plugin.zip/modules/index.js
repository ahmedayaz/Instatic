// src/core/plugin-sdk/capabilities.ts
var PLUGIN_CAPABILITIES = [
  {
    permission: "admin.navigation",
    label: "Add pages to the admin navigation",
    description: "Allows the plugin to add pages to the CMS admin sidebar and plugin page router.",
    risk: "low",
    surfaces: ["manifest", "admin"]
  },
  {
    permission: "cms.storage",
    label: "Read and write plugin backend storage",
    description: "Allows the plugin to read and write records in resources declared by its manifest.",
    risk: "medium",
    surfaces: ["admin", "editor", "server", "cms"]
  },
  {
    permission: "cms.routes",
    label: "Register backend CMS routes",
    description: "Allows the plugin server entrypoint to register authenticated backend routes.",
    risk: "high",
    surfaces: ["server", "cms"]
  },
  {
    permission: "cms.hooks",
    label: "Subscribe to CMS lifecycle events and filters",
    description: "Allows the plugin server entrypoint to listen to CMS events (publish, content changes, page updates) and to register filters that transform values before they leave the CMS.",
    risk: "high",
    surfaces: ["server", "cms"]
  },
  {
    permission: "editor.toolbar",
    label: "Add controls to the editor toolbar",
    description: "Allows the plugin editor entrypoint to add toolbar buttons.",
    risk: "medium",
    surfaces: ["editor"]
  },
  {
    permission: "editor.commands",
    label: "Register editor commands",
    description: "Allows the plugin editor entrypoint to register commands that can be invoked by editor UI. Also grants registration of Command Spotlight palette commands (api.editor.palette.registerCommand) and live-search providers (api.editor.palette.registerProvider).",
    risk: "medium",
    surfaces: ["editor"]
  },
  {
    permission: "editor.store.read",
    label: "Read editor state",
    description: "Allows the plugin to inspect the current editor store state.",
    risk: "medium",
    surfaces: ["editor"]
  },
  {
    permission: "editor.store.write",
    label: "Modify editor state",
    description: "Allows the plugin to mutate editor store state through a host transaction.",
    risk: "high",
    surfaces: ["editor"]
  },
  {
    permission: "editor.canvas",
    label: "Add canvas overlays",
    description: "Allows the plugin to register canvas overlay React components — annotation pins, custom selection adornments, measurement tools — that mount on top of the rendered canvas via `editor.canvas.registerOverlay`.",
    risk: "high",
    surfaces: ["editor"]
  },
  {
    permission: "editor.panels",
    label: "Add editor panels",
    description: "Allows the plugin to register panels that mount in the editor's left sidebar (custom inspectors, plugin dashboards, review queues).",
    risk: "medium",
    surfaces: ["editor"]
  },
  {
    permission: "modules.register",
    label: "Register page builder modules",
    description: "Allows the plugin to ship new modules that show up in the canvas module library.",
    risk: "high",
    surfaces: ["editor", "manifest"]
  },
  {
    permission: "loops.register",
    label: "Register loop entity sources",
    description: "Allows the plugin to register data sources for the base.loop module (e.g. external collections, custom queries).",
    risk: "medium",
    surfaces: ["editor", "server", "manifest"]
  },
  {
    permission: "visualComponents.register",
    label: "Install Visual Components / templates into the site",
    description: "Allows the plugin to ship Visual Components, page templates, and class packs that are imported into the user's site on activation.",
    risk: "medium",
    surfaces: ["admin", "manifest"]
  },
  {
    permission: "dashboard.widgets.register",
    label: "Register dashboard widgets",
    description: "Allows the plugin to add cards to the admin dashboard grid (e.g. analytics charts, queue counters, plugin-specific stats). Each widget runs as a regular React component inside the host's admin shell.",
    risk: "medium",
    surfaces: ["admin"]
  },
  {
    permission: "frontend.scripts",
    label: "Inject scripts into published pages",
    description: "Allows the plugin to ship a JavaScript file that is loaded on every published page (analytics, third-party widgets, custom runtimes).",
    risk: "high",
    surfaces: ["frontend", "manifest"]
  },
  {
    permission: "frontend.tracker",
    label: "Receive frontend analytics events",
    description: "Allows the plugin to receive structured tracker events from published pages and store them in plugin-owned storage.",
    risk: "medium",
    surfaces: ["frontend", "server", "manifest"]
  },
  {
    permission: "cms.schedule",
    label: "Register scheduled jobs",
    description: "Allows the plugin to register handlers that fire on a cadence (hourly / daily / weekly / monthly / every-N-minutes). Each handler runs inside the QuickJS sandbox with a per-fire wall-clock budget; the host scheduler tick drives dispatch and records run history.",
    risk: "high",
    surfaces: ["server"]
  },
  {
    permission: "media.storage.adapter",
    label: "Provide a media storage backend",
    description: "Allows the plugin to register an exclusive storage adapter that the host elects per asset role (original / variant / avatar / font). The adapter issues signed upload targets; the host streams bytes directly. Required for S3, R2, GCS, Azure, and similar backends.",
    risk: "dangerous",
    surfaces: ["server", "cms"]
  },
  {
    permission: "media.url.transform",
    label: "Rewrite media URLs at render time",
    description: "Allows the plugin to register a pure URL transformer applied to every media path (originals + responsive variants) in the publisher, editor preview, and admin media library. Typical use: passive CDN URL prefixing.",
    risk: "medium",
    surfaces: ["server", "cms"]
  },
  {
    permission: "media.variant.delegate",
    label: "Delegate responsive variant generation to an external service",
    description: "Allows the plugin to replace the host's local image-variant ladder with a URL template (image-transform CDNs — Cloudflare Images, Imgix, Bunny Optimizer). Only one such plugin can win per host.",
    risk: "high",
    surfaces: ["server", "cms"]
  },
  {
    permission: "unstable.internals",
    label: "Use unstable internal APIs",
    description: "Reserved for trusted first-party plugins that need unstable host internals.",
    risk: "dangerous",
    surfaces: ["admin", "editor", "server", "cms"]
  }
];
var capabilityByPermission = new Map(PLUGIN_CAPABILITIES.map((capability) => [capability.permission, capability]));
// src/core/plugin-sdk/builders/defineModule.ts
function defineModule(config) {
  if (typeof config.id !== "string" || !config.id.includes(".")) {
    throw new Error(`[plugin-sdk] Module id "${config.id}" must be namespaced as "<pluginId>.<name>".`);
  }
  return {
    id: config.id,
    name: config.name,
    description: config.description,
    category: config.category,
    version: config.version ?? "1.0.0",
    defaults: config.defaults,
    schema: config.schema,
    canHaveChildren: config.canHaveChildren,
    htmlTag: config.htmlTag,
    ...config.dependencies ? { dependencies: config.dependencies } : {},
    ...config.editorRuntime ? { editorRuntime: config.editorRuntime } : {},
    render: (props, children) => config.render({ props, children }),
    ...config.preview ? { preview: (props, children) => config.preview({ props, children }) } : {}
  };
}
// src/core/plugin-sdk/builders/controls.ts
var control = {
  text(label, options = {}) {
    return { type: "text", label, ...options };
  },
  textarea(label, options = {}) {
    return { type: "textarea", label, ...options };
  },
  number(label, options = {}) {
    return { type: "number", label, ...options };
  },
  color(label, options = {}) {
    return { type: "color", label, ...options };
  },
  select(label, optionsOrOptionsList) {
    const list = Array.isArray(optionsOrOptionsList) ? optionsOrOptionsList : optionsOrOptionsList.options;
    const description = Array.isArray(optionsOrOptionsList) ? undefined : optionsOrOptionsList.description;
    return { type: "select", label, options: list, ...description ? { description } : {} };
  },
  toggle(label, options = {}) {
    return { type: "toggle", label, ...options };
  },
  image(label, options = {}) {
    return { type: "image", label, ...options };
  },
  url(label, options = {}) {
    return { type: "url", label, ...options };
  }
};
// src/core/plugin-sdk/builders/html.ts
var HTML_ESCAPE_RE = /[&<>"']/g;
var HTML_ESCAPE_MAP = {
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  '"': "&quot;",
  "'": "&#39;"
};
function escapeHtml(value) {
  return value.replace(HTML_ESCAPE_RE, (ch) => HTML_ESCAPE_MAP[ch]);
}
var RAW_BRAND = Symbol.for("@pagebuilder/plugin-sdk/raw");
function isRawHtml(value) {
  return Boolean(value) && typeof value === "object" && value[RAW_BRAND] === true;
}
function renderInterpolation(value) {
  if (value === null || value === undefined)
    return "";
  if (typeof value === "string")
    return escapeHtml(value);
  if (typeof value === "number" || typeof value === "boolean")
    return String(value);
  if (isRawHtml(value))
    return value.value;
  if (Array.isArray(value))
    return value.map(renderInterpolation).join("");
  console.warn("[plugin-sdk:html] Unsupported interpolation type", typeof value, value);
  return escapeHtml(String(value));
}
function html(strings, ...values) {
  let out = "";
  for (let i = 0;i < strings.length; i++) {
    out += strings[i];
    if (i < values.length)
      out += renderInterpolation(values[i]);
  }
  return out;
}
// examples/plugins/search/modules/searchBox.ts
var searchBox_default = defineModule({
  id: "pagebuilder.search.search-box",
  name: "Search Box",
  description: "Instant-search input with dropdown results. Fetches from the Search plugin endpoint.",
  category: "Search",
  version: "1.0.0",
  htmlTag: "div",
  canHaveChildren: false,
  defaults: {
    placeholder: "Search...",
    resultsPagePath: "/search",
    inputLabel: "Search"
  },
  schema: {
    placeholder: control.text("Placeholder", {
      placeholder: "Search...",
      description: "Hint text shown inside the search input."
    }),
    resultsPagePath: control.text("Results page path", {
      placeholder: "/search",
      description: 'URL of the full search-results page. "View all results" links here.'
    }),
    inputLabel: control.text("Input label", {
      placeholder: "Search",
      description: "Accessible label for the search input (visually hidden)."
    })
  },
  render: ({ props }) => {
    const placeholder = String(props.placeholder ?? "Search...");
    const resultsPagePath = String(props.resultsPagePath ?? "/search");
    const inputLabel = String(props.inputLabel ?? "Search");
    const css = `
      .pb-search-box{position:relative;font-family:inherit;}
      .pb-search-box__label{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border:0;}
      .pb-search-box__input{display:block;width:100%;padding:10px 14px;border:1px solid var(--pb-search-border,#d1d5db);border-radius:6px;font-size:1rem;font-family:inherit;background:var(--pb-search-bg,#fff);color:var(--pb-search-text,inherit);outline:none;box-sizing:border-box;}
      .pb-search-box__input:focus{border-color:var(--pb-search-focus,#2563eb);box-shadow:0 0 0 3px var(--pb-search-focus-ring,rgba(37,99,235,0.2));}
      .pb-search-box__dropdown{display:none;position:absolute;top:calc(100% + 4px);left:0;right:0;background:var(--pb-search-bg,#fff);border:1px solid var(--pb-search-border,#d1d5db);border-radius:6px;box-shadow:0 4px 16px rgba(0,0,0,0.12);z-index:200;overflow:hidden;}
      .pb-search-box__dropdown.is-open{display:block;}
      .pb-search-box__results{list-style:none;margin:0;padding:4px;}
      .pb-search-box__result a{display:block;padding:8px 12px;border-radius:4px;text-decoration:none;color:inherit;}
      .pb-search-box__result a:hover{background:var(--pb-search-hover,#f3f4f6);}
      .pb-search-box__result-title{display:block;font-size:0.925rem;font-weight:500;}
      .pb-search-box__result-excerpt{display:block;font-size:0.8rem;color:var(--pb-search-muted,#6b7280);margin-top:2px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
      .pb-search-box__viewall{display:block;padding:8px 12px;border-top:1px solid var(--pb-search-border,#d1d5db);font-size:0.875rem;color:var(--pb-search-accent,#2563eb);text-decoration:none;text-align:center;}
      .pb-search-box__viewall:hover{background:var(--pb-search-hover,#f3f4f6);}
      .pb-search-box__empty{padding:12px;text-align:center;font-size:0.875rem;color:var(--pb-search-muted,#6b7280);}
    `;
    const script = `
(function(){
  var ENDPOINT='/admin/api/cms/plugins/pagebuilder.search/runtime/search';
  var RESULTS_PAGE='${resultsPagePath}';
  var PER_PAGE=5;
  var boxes=document.querySelectorAll('.pb-search-box');
  boxes.forEach(function(box){
    var input=box.querySelector('.pb-search-box__input');
    var dropdown=box.querySelector('.pb-search-box__dropdown');
    var resultsList=box.querySelector('.pb-search-box__results');
    var viewAll=box.querySelector('.pb-search-box__viewall');
    if(!input||!dropdown||!resultsList||!viewAll)return;
    var timer=null;
    var lastQ='';
    function close(){dropdown.classList.remove('is-open');}
    function open(){dropdown.classList.add('is-open');}
    function render(hits,q){
      resultsList.innerHTML='';
      if(!hits||hits.length===0){
        var empty=document.createElement('div');
        empty.className='pb-search-box__empty';
        empty.textContent='No results for "'+q+'"';
        resultsList.appendChild(empty);
      }else{
        hits.forEach(function(h){
          var li=document.createElement('li');
          li.className='pb-search-box__result';
          var a=document.createElement('a');
          a.href=safeHref(h.slug||'#');
          a.innerHTML='<span class="pb-search-box__result-title">'+escHtml(h.title||h.slug)+'</span>'
            +(h.excerpt?'<span class="pb-search-box__result-excerpt">'+escHtml(h.excerpt)+'</span>':'');
          li.appendChild(a);
          resultsList.appendChild(li);
        });
      }
      viewAll.href=RESULTS_PAGE+'?q='+encodeURIComponent(q);
      viewAll.textContent='View all results →';
    }
    function escHtml(s){
      return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
    }
    function safeHref(slug){
      return(slug.startsWith('/')||slug.startsWith('https://')||slug.startsWith('http://'))?slug:'#';
    }
    function doSearch(q){
      fetch(ENDPOINT+'?q='+encodeURIComponent(q)+'&per-page='+PER_PAGE)
        .then(function(r){return r.json();})
        .then(function(body){render(body.results,q);open();})
        .catch(function(){close();});
    }
    input.addEventListener('input',function(){
      var q=(input.value||'').trim();
      clearTimeout(timer);
      if(!q){close();return;}
      if(q===lastQ){open();return;}
      lastQ=q;
      timer=setTimeout(function(){doSearch(q);},250);
    });
    input.addEventListener('keydown',function(e){
      if(e.key==='Escape'){close();}
    });
    document.addEventListener('click',function(e){
      if(!box.contains(e.target)){close();}
    });
  });
})();
`;
    return {
      html: html`
        <div class="pb-search-box">
          <label class="pb-search-box__label" for="pb-search-input">${inputLabel}</label>
          <input
            class="pb-search-box__input"
            id="pb-search-input"
            type="search"
            placeholder="${placeholder}"
            aria-label="${inputLabel}"
            autocomplete="off"
          />
          <div class="pb-search-box__dropdown" role="listbox" aria-label="Search results">
            <ul class="pb-search-box__results" role="list"></ul>
            <a class="pb-search-box__viewall" href="${resultsPagePath}?q=">View all results &rarr;</a>
          </div>
          <script>${script}</script>
        </div>
      `,
      css
    };
  }
});

// examples/plugins/search/modules/searchResults.ts
var searchResults_default = defineModule({
  id: "pagebuilder.search.search-results",
  name: "Search Results",
  description: "Full-page search results list with pagination. Drop on a page at /search.",
  category: "Search",
  version: "1.0.0",
  htmlTag: "section",
  canHaveChildren: false,
  defaults: {
    perPage: 10,
    noResultsMessage: "No results found. Try a different search term."
  },
  schema: {
    perPage: control.number("Results per page", {
      min: 1,
      max: 50,
      description: "How many results to show per page."
    }),
    noResultsMessage: control.textarea("No-results message", {
      rows: 2,
      description: "Shown when the query returns zero hits."
    })
  },
  render: ({ props }) => {
    const perPage = Number(props.perPage ?? 10);
    const noResultsMessage = String(props.noResultsMessage ?? "No results found.");
    const css = `
      .pb-search-results{font-family:inherit;max-width:720px;margin:0 auto;padding:24px 0;}
      .pb-search-results__query{margin-bottom:24px;}
      .pb-search-results__query-form{display:flex;gap:8px;}
      .pb-search-results__query-input{flex:1;padding:10px 14px;border:1px solid var(--pb-sr-border,#d1d5db);border-radius:6px;font-size:1rem;font-family:inherit;background:var(--pb-sr-bg,#fff);color:inherit;outline:none;box-sizing:border-box;}
      .pb-search-results__query-input:focus{border-color:var(--pb-sr-accent,#2563eb);box-shadow:0 0 0 3px var(--pb-sr-focus-ring,rgba(37,99,235,0.2));}
      .pb-search-results__query-btn{padding:10px 20px;background:var(--pb-sr-accent,#2563eb);color:#fff;border:none;border-radius:6px;font-size:1rem;font-family:inherit;cursor:pointer;}
      .pb-search-results__query-btn:hover{opacity:0.9;}
      .pb-search-results__meta{font-size:0.875rem;color:var(--pb-sr-muted,#6b7280);margin-bottom:16px;}
      .pb-search-results__list{list-style:none;padding:0;margin:0;}
      .pb-search-results__item{padding:16px 0;border-bottom:1px solid var(--pb-sr-border,#e5e7eb);}
      .pb-search-results__item:last-child{border-bottom:none;}
      .pb-search-results__item-title{font-size:1.1rem;font-weight:600;margin:0 0 4px;}
      .pb-search-results__item-title a{color:var(--pb-sr-accent,#2563eb);text-decoration:none;}
      .pb-search-results__item-title a:hover{text-decoration:underline;}
      .pb-search-results__item-slug{font-size:0.8rem;color:var(--pb-sr-muted,#6b7280);margin:0 0 6px;}
      .pb-search-results__item-excerpt{font-size:0.9rem;color:var(--pb-sr-text,inherit);margin:0;line-height:1.5;}
      .pb-search-results__empty{padding:24px;text-align:center;color:var(--pb-sr-muted,#6b7280);}
      .pb-search-results__pagination{display:flex;align-items:center;gap:8px;margin-top:24px;flex-wrap:wrap;}
      .pb-search-results__page-btn{padding:6px 14px;border:1px solid var(--pb-sr-border,#d1d5db);border-radius:4px;background:var(--pb-sr-bg,#fff);color:inherit;cursor:pointer;font-family:inherit;font-size:0.875rem;}
      .pb-search-results__page-btn:hover:not(:disabled){background:var(--pb-sr-hover,#f3f4f6);}
      .pb-search-results__page-btn:disabled{opacity:0.5;cursor:default;}
      .pb-search-results__page-btn.is-current{background:var(--pb-sr-accent,#2563eb);color:#fff;border-color:var(--pb-sr-accent,#2563eb);}
      .pb-search-results__loading{text-align:center;padding:32px;color:var(--pb-sr-muted,#6b7280);}
    `;
    const script = `
(function(){
  var ENDPOINT='/admin/api/cms/plugins/pagebuilder.search/runtime/search';
  var PER_PAGE=${perPage};
  var NO_RESULTS_MSG=${JSON.stringify(noResultsMessage)};

  function getParam(name){
    var params=new URLSearchParams(window.location.search);
    return params.get(name)||'';
  }

  function escHtml(s){
    return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
  }
  function safeHref(slug){
    return(slug.startsWith('/')||slug.startsWith('https://')||slug.startsWith('http://'))?slug:'#';
  }

  function setParam(name,value){
    var params=new URLSearchParams(window.location.search);
    if(value){params.set(name,value);}else{params.delete(name);}
    var newUrl=window.location.pathname+'?'+params.toString();
    window.history.replaceState(null,'',newUrl);
  }

  function renderMeta(q,total,tookMs,page){
    var meta=document.querySelector('.pb-search-results__meta');
    if(!meta)return;
    if(!q){meta.textContent='Enter a search term above.';return;}
    var from=(page-1)*PER_PAGE+1;
    var to=Math.min(page*PER_PAGE,total);
    meta.textContent=total>0
      ?('Showing '+from+'–'+to+' of '+total+' results for "'+q+'" ('+tookMs+'ms)')
      :('No results for "'+q+'"');
  }

  function renderResults(hits){
    var list=document.querySelector('.pb-search-results__list');
    if(!list)return;
    list.innerHTML='';
    if(!hits||hits.length===0){
      var empty=document.createElement('div');
      empty.className='pb-search-results__empty';
      empty.textContent=NO_RESULTS_MSG;
      list.parentNode.insertBefore(empty,list);
      return;
    }
    hits.forEach(function(h){
      var li=document.createElement('li');
      li.className='pb-search-results__item';
      li.innerHTML=(
        '<h2 class="pb-search-results__item-title"><a href="'+safeHref(h.slug)+'">'+escHtml(h.title)+'</a></h2>'
        +'<p class="pb-search-results__item-slug">'+escHtml(h.slug)+'</p>'
        +(h.excerpt?'<p class="pb-search-results__item-excerpt">'+escHtml(h.excerpt)+'</p>':'')
      );
      list.appendChild(li);
    });
  }

  function renderPagination(total,currentPage){
    var container=document.querySelector('.pb-search-results__pagination');
    if(!container)return;
    container.innerHTML='';
    var totalPages=Math.ceil(total/PER_PAGE);
    if(totalPages<=1)return;

    function pageBtn(label,page,isCurrent,disabled){
      var btn=document.createElement('button');
      btn.className='pb-search-results__page-btn'+(isCurrent?' is-current':'');
      btn.textContent=label;
      btn.disabled=disabled||false;
      if(!disabled&&!isCurrent){
        btn.addEventListener('click',function(){doSearch(getParam('q'),page);});
      }
      return btn;
    }

    container.appendChild(pageBtn('← Prev',currentPage-1,false,currentPage===1));

    var start=Math.max(1,currentPage-2);
    var end=Math.min(totalPages,currentPage+2);
    if(start>1){
      container.appendChild(pageBtn('1',1,false,false));
      if(start>2){var ell=document.createElement('span');ell.textContent='…';container.appendChild(ell);}
    }
    for(var p=start;p<=end;p++){
      container.appendChild(pageBtn(String(p),p,p===currentPage,false));
    }
    if(end<totalPages){
      if(end<totalPages-1){var ell2=document.createElement('span');ell2.textContent='…';container.appendChild(ell2);}
      container.appendChild(pageBtn(String(totalPages),totalPages,false,false));
    }
    container.appendChild(pageBtn('Next →',currentPage+1,false,currentPage>=totalPages));
  }

  function showLoading(){
    var list=document.querySelector('.pb-search-results__list');
    var empty=document.querySelector('.pb-search-results__empty');
    if(empty&&empty.parentNode)empty.parentNode.removeChild(empty);
    if(list)list.innerHTML='<li class="pb-search-results__loading">Loading…</li>';
  }

  function doSearch(q,page){
    page=page||1;
    setParam('q',q);
    setParam('page',String(page));
    if(!q){renderMeta('',0,0,1);renderResults([]);renderPagination(0,1);return;}
    showLoading();
    fetch(ENDPOINT+'?q='+encodeURIComponent(q)+'&page='+page+'&per-page='+PER_PAGE)
      .then(function(r){return r.json();})
      .then(function(body){
        renderMeta(q,body.total||0,body.took_ms||0,page);
        renderResults(body.results||[]);
        renderPagination(body.total||0,page);
      })
      .catch(function(err){
        var list=document.querySelector('.pb-search-results__list');
        if(list)list.innerHTML='<li class="pb-search-results__empty">Search unavailable. Please try again.</li>';
      });
  }

  // Wire up the form.
  var form=document.querySelector('.pb-search-results__query-form');
  if(form){
    var input=form.querySelector('.pb-search-results__query-input');
    form.addEventListener('submit',function(e){
      e.preventDefault();
      doSearch((input&&input.value)||'',1);
    });
  }

  // Run initial search from URL.
  var q=getParam('q');
  var page=parseInt(getParam('page'),10)||1;
  if(input&&q)input.value=q;
  doSearch(q,page);
})();
`;
    return {
      html: html`
        <section class="pb-search-results">
          <div class="pb-search-results__query">
            <form class="pb-search-results__query-form" role="search">
              <input
                class="pb-search-results__query-input"
                type="search"
                placeholder="Search…"
                aria-label="Search"
                autocomplete="off"
              />
              <button class="pb-search-results__query-btn" type="submit">Search</button>
            </form>
          </div>
          <div class="pb-search-results__meta"></div>
          <ul class="pb-search-results__list" aria-live="polite" aria-label="Search results"></ul>
          <nav class="pb-search-results__pagination" aria-label="Pagination"></nav>
          <script>${script}</script>
        </section>
      `,
      css
    };
  }
});

// examples/plugins/search/__modules-facade.ts
var __modules_facade_default = [searchBox_default, searchResults_default];
export {
  __modules_facade_default as default
};
