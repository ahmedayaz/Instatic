// src/core/plugin-sdk/capabilities.ts
var PLUGIN_CAPABILITIES = [
  {
    permission: "admin.navigation",
    label: "Add pages to the admin navigation",
    description: "Allows the plugin to add pages to the CMS admin sidebar and plugin page router.",
    risk: "low",
    surfaces: ["manifest", "admin"]
  },
  {
    permission: "cms.storage",
    label: "Read and write plugin backend storage",
    description: "Allows the plugin to read and write records in resources declared by its manifest.",
    risk: "medium",
    surfaces: ["admin", "editor", "server", "cms"]
  },
  {
    permission: "cms.routes",
    label: "Register backend CMS routes",
    description: "Allows the plugin server entrypoint to register authenticated backend routes.",
    risk: "high",
    surfaces: ["server", "cms"]
  },
  {
    permission: "cms.hooks",
    label: "Subscribe to CMS lifecycle events and filters",
    description: "Allows the plugin server entrypoint to listen to CMS events (publish, content changes, page updates) and to register filters that transform values before they leave the CMS.",
    risk: "high",
    surfaces: ["server", "cms"]
  },
  {
    permission: "editor.toolbar",
    label: "Add controls to the editor toolbar",
    description: "Allows the plugin editor entrypoint to add toolbar buttons.",
    risk: "medium",
    surfaces: ["editor"]
  },
  {
    permission: "editor.commands",
    label: "Register editor commands",
    description: "Allows the plugin editor entrypoint to register commands that can be invoked by editor UI. Also grants registration of Command Spotlight palette commands (api.editor.palette.registerCommand) and live-search providers (api.editor.palette.registerProvider).",
    risk: "medium",
    surfaces: ["editor"]
  },
  {
    permission: "editor.store.read",
    label: "Read editor state",
    description: "Allows the plugin to inspect the current editor store state.",
    risk: "medium",
    surfaces: ["editor"]
  },
  {
    permission: "editor.store.write",
    label: "Modify editor state",
    description: "Allows the plugin to mutate editor store state through a host transaction.",
    risk: "high",
    surfaces: ["editor"]
  },
  {
    permission: "editor.canvas",
    label: "Add canvas overlays",
    description: "Allows the plugin to register canvas overlay React components — annotation pins, custom selection adornments, measurement tools — that mount on top of the rendered canvas via `editor.canvas.registerOverlay`.",
    risk: "high",
    surfaces: ["editor"]
  },
  {
    permission: "editor.panels",
    label: "Add editor panels",
    description: "Allows the plugin to register panels that mount in the editor's left sidebar (custom inspectors, plugin dashboards, review queues).",
    risk: "medium",
    surfaces: ["editor"]
  },
  {
    permission: "modules.register",
    label: "Register page builder modules",
    description: "Allows the plugin to ship new modules that show up in the canvas module library.",
    risk: "high",
    surfaces: ["editor", "manifest"]
  },
  {
    permission: "loops.register",
    label: "Register loop entity sources",
    description: "Allows the plugin to register data sources for the base.loop module (e.g. external collections, custom queries).",
    risk: "medium",
    surfaces: ["editor", "server", "manifest"]
  },
  {
    permission: "visualComponents.register",
    label: "Install Visual Components / templates into the site",
    description: "Allows the plugin to ship Visual Components, page templates, and class packs that are imported into the user's site on activation.",
    risk: "medium",
    surfaces: ["admin", "manifest"]
  },
  {
    permission: "dashboard.widgets.register",
    label: "Register dashboard widgets",
    description: "Allows the plugin to add cards to the admin dashboard grid (e.g. analytics charts, queue counters, plugin-specific stats). Each widget runs as a regular React component inside the host's admin shell.",
    risk: "medium",
    surfaces: ["admin"]
  },
  {
    permission: "frontend.scripts",
    label: "Inject scripts into published pages",
    description: "Allows the plugin to ship a JavaScript file that is loaded on every published page (analytics, third-party widgets, custom runtimes).",
    risk: "high",
    surfaces: ["frontend", "manifest"]
  },
  {
    permission: "frontend.tracker",
    label: "Receive frontend analytics events",
    description: "Allows the plugin to receive structured tracker events from published pages and store them in plugin-owned storage.",
    risk: "medium",
    surfaces: ["frontend", "server", "manifest"]
  },
  {
    permission: "cms.schedule",
    label: "Register scheduled jobs",
    description: "Allows the plugin to register handlers that fire on a cadence (hourly / daily / weekly / monthly / every-N-minutes). Each handler runs inside the QuickJS sandbox with a per-fire wall-clock budget; the host scheduler tick drives dispatch and records run history.",
    risk: "high",
    surfaces: ["server"]
  },
  {
    permission: "media.storage.adapter",
    label: "Provide a media storage backend",
    description: "Allows the plugin to register an exclusive storage adapter that the host elects per asset role (original / variant / avatar / font). The adapter issues signed upload targets; the host streams bytes directly. Required for S3, R2, GCS, Azure, and similar backends.",
    risk: "dangerous",
    surfaces: ["server", "cms"]
  },
  {
    permission: "media.url.transform",
    label: "Rewrite media URLs at render time",
    description: "Allows the plugin to register a pure URL transformer applied to every media path (originals + responsive variants) in the publisher, editor preview, and admin media library. Typical use: passive CDN URL prefixing.",
    risk: "medium",
    surfaces: ["server", "cms"]
  },
  {
    permission: "media.variant.delegate",
    label: "Delegate responsive variant generation to an external service",
    description: "Allows the plugin to replace the host's local image-variant ladder with a URL template (image-transform CDNs — Cloudflare Images, Imgix, Bunny Optimizer). Only one such plugin can win per host.",
    risk: "high",
    surfaces: ["server", "cms"]
  },
  {
    permission: "unstable.internals",
    label: "Use unstable internal APIs",
    description: "Reserved for trusted first-party plugins that need unstable host internals.",
    risk: "dangerous",
    surfaces: ["admin", "editor", "server", "cms"]
  }
];
var capabilityByPermission = new Map(PLUGIN_CAPABILITIES.map((capability) => [capability.permission, capability]));
// src/core/plugin-sdk/builders/defineModule.ts
function defineModule(config) {
  if (typeof config.id !== "string" || !config.id.includes(".")) {
    throw new Error(`[plugin-sdk] Module id "${config.id}" must be namespaced as "<pluginId>.<name>".`);
  }
  return {
    id: config.id,
    name: config.name,
    description: config.description,
    category: config.category,
    version: config.version ?? "1.0.0",
    defaults: config.defaults,
    schema: config.schema,
    canHaveChildren: config.canHaveChildren,
    htmlTag: config.htmlTag,
    ...config.dependencies ? { dependencies: config.dependencies } : {},
    ...config.editorRuntime ? { editorRuntime: config.editorRuntime } : {},
    render: (props, children) => config.render({ props, children }),
    ...config.preview ? { preview: (props, children) => config.preview({ props, children }) } : {}
  };
}
// src/core/plugin-sdk/builders/controls.ts
var control = {
  text(label, options = {}) {
    return { type: "text", label, ...options };
  },
  textarea(label, options = {}) {
    return { type: "textarea", label, ...options };
  },
  number(label, options = {}) {
    return { type: "number", label, ...options };
  },
  color(label, options = {}) {
    return { type: "color", label, ...options };
  },
  select(label, optionsOrOptionsList) {
    const list = Array.isArray(optionsOrOptionsList) ? optionsOrOptionsList : optionsOrOptionsList.options;
    const description = Array.isArray(optionsOrOptionsList) ? undefined : optionsOrOptionsList.description;
    return { type: "select", label, options: list, ...description ? { description } : {} };
  },
  toggle(label, options = {}) {
    return { type: "toggle", label, ...options };
  },
  image(label, options = {}) {
    return { type: "image", label, ...options };
  },
  url(label, options = {}) {
    return { type: "url", label, ...options };
  }
};
// src/core/plugin-sdk/builders/html.ts
var HTML_ESCAPE_RE = /[&<>"']/g;
var HTML_ESCAPE_MAP = {
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  '"': "&quot;",
  "'": "&#39;"
};
function escapeHtml(value) {
  return value.replace(HTML_ESCAPE_RE, (ch) => HTML_ESCAPE_MAP[ch]);
}
var RAW_BRAND = Symbol.for("@pagebuilder/plugin-sdk/raw");
function isRawHtml(value) {
  return Boolean(value) && typeof value === "object" && value[RAW_BRAND] === true;
}
function raw(value) {
  return { [RAW_BRAND]: true, value };
}
function renderInterpolation(value) {
  if (value === null || value === undefined)
    return "";
  if (typeof value === "string")
    return escapeHtml(value);
  if (typeof value === "number" || typeof value === "boolean")
    return String(value);
  if (isRawHtml(value))
    return value.value;
  if (Array.isArray(value))
    return value.map(renderInterpolation).join("");
  console.warn("[plugin-sdk:html] Unsupported interpolation type", typeof value, value);
  return escapeHtml(String(value));
}
function html(strings, ...values) {
  let out = "";
  for (let i = 0;i < strings.length; i++) {
    out += strings[i];
    if (i < values.length)
      out += renderInterpolation(values[i]);
  }
  return out;
}
function safeUrl(value) {
  const s = String(value ?? "");
  if (/^javascript:/i.test(s) || /^vbscript:/i.test(s))
    return "#";
  return s;
}
// examples/plugins/forms-builder/modules/checkbox.ts
var checkbox_default = defineModule({
  id: "pagebuilder.forms.checkbox",
  name: "Checkbox",
  description: "A single checkbox field.",
  category: "Forms",
  htmlTag: "div",
  canHaveChildren: false,
  defaults: {
    name: "agree",
    label: "I agree to the terms",
    required: false,
    helperText: ""
  },
  schema: {
    name: control.text("Field Name", {
      placeholder: "agree",
      description: "HTML name attribute — must be unique within the form."
    }),
    label: control.text("Label"),
    required: control.toggle("Required"),
    helperText: control.text("Helper Text")
  },
  render: ({ props }) => {
    const requiredAttr = props.required ? " required" : "";
    const asterisk = props.required ? raw('<span class="pb-forms-required" aria-hidden="true">*</span>') : raw("");
    const helper = props.helperText ? html`<small class="pb-forms-help">${props.helperText}</small>` : "";
    return {
      html: html`<div class="pb-forms-field pb-forms-field--checkbox">
  <label class="pb-forms-label pb-forms-label--checkbox">
    <input
      class="pb-forms-checkbox"
      type="checkbox"
      name="${props.name}"
      value="1"${raw(requiredAttr)}
    >
    ${props.label}${asterisk}
  </label>
  ${raw(helper)}
</div>`,
      css: `
.pb-forms-field--checkbox .pb-forms-label--checkbox{display:flex;align-items:flex-start;gap:8px;font-size:0.9375rem;cursor:pointer;}
.pb-forms-checkbox{flex-shrink:0;margin-top:3px;width:15px;height:15px;}
`
    };
  }
});

// examples/plugins/forms-builder/modules/honeypot.ts
var honeypot_default = defineModule({
  id: "pagebuilder.forms.honeypot",
  name: "Honeypot (Anti-Spam)",
  description: "Invisible honeypot field for bot detection. Drop once per form.",
  category: "Forms",
  htmlTag: "div",
  canHaveChildren: false,
  defaults: {
    name: "_hp_email"
  },
  schema: {
    name: control.text("Field Name", {
      placeholder: "_hp_email",
      description: 'Must begin with "_hp_". The server rejects any submission where this field is non-empty.'
    })
  },
  render: ({ props }) => ({
    html: raw(`<div aria-hidden="true" style="position:absolute;left:-9999px;top:-9999px;overflow:hidden;height:0;">` + `<label for="pb-hp-${props.name}">Leave this field empty</label>` + `<input id="pb-hp-${props.name}" type="text" name="${props.name}" value="" tabindex="-1" autocomplete="off">` + `</div>`)
  })
});

// examples/plugins/forms-builder/modules/select.ts
function parseOptions(raw2) {
  return raw2.split(`
`).map((line) => line.trim()).filter(Boolean).map((line) => {
    const sep = line.indexOf(":");
    if (sep === -1)
      return { label: line, value: line };
    return { label: line.slice(0, sep).trim(), value: line.slice(sep + 1).trim() };
  });
}
var select_default = defineModule({
  id: "pagebuilder.forms.select",
  name: "Select",
  description: "Dropdown selection field.",
  category: "Forms",
  htmlTag: "div",
  canHaveChildren: false,
  defaults: {
    name: "choice",
    label: "Choose an option",
    required: false,
    helperText: "",
    options: `Option A:a
Option B:b
Option C:c`
  },
  schema: {
    name: control.text("Field Name", {
      placeholder: "choice",
      description: "HTML name attribute — must be unique within the form."
    }),
    label: control.text("Label"),
    required: control.toggle("Required"),
    helperText: control.text("Helper Text"),
    options: control.textarea("Options", {
      rows: 5,
      description: 'One option per line. Format: "Label:value" or just "value".',
      placeholder: `Option A:a
Option B:b`
    })
  },
  render: ({ props }) => {
    const requiredAttr = props.required ? " required" : "";
    const asterisk = props.required ? raw('<span class="pb-forms-required" aria-hidden="true">*</span>') : raw("");
    const helper = props.helperText ? html`<small class="pb-forms-help">${props.helperText}</small>` : "";
    const opts = parseOptions(String(props.options));
    const optionsHtml = opts.map((o) => html`<option value="${o.value}">${o.label}</option>`).join(`
  `);
    return {
      html: html`<div class="pb-forms-field">
  <label class="pb-forms-label" for="pb-${props.name}">${props.label}${asterisk}</label>
  <select class="pb-forms-control" id="pb-${props.name}" name="${props.name}"${raw(requiredAttr)}>
  ${raw(optionsHtml)}
  </select>
  ${raw(helper)}
</div>`
    };
  }
});

// examples/plugins/forms-builder/modules/radio.ts
function parseOptions2(rawStr) {
  return rawStr.split(`
`).map((line) => line.trim()).filter(Boolean).map((line) => {
    const sep = line.indexOf(":");
    if (sep === -1)
      return { label: line, value: line };
    return { label: line.slice(0, sep).trim(), value: line.slice(sep + 1).trim() };
  });
}
var radio_default = defineModule({
  id: "pagebuilder.forms.radio-group",
  name: "Radio Group",
  description: "A group of mutually exclusive radio buttons.",
  category: "Forms",
  htmlTag: "fieldset",
  canHaveChildren: false,
  defaults: {
    name: "pick",
    label: "Pick one",
    required: false,
    helperText: "",
    options: `Yes:yes
No:no
Maybe:maybe`
  },
  schema: {
    name: control.text("Field Name", {
      placeholder: "pick",
      description: "HTML name attribute — shared by all radio inputs in the group."
    }),
    label: control.text("Legend Label"),
    required: control.toggle("Required"),
    helperText: control.text("Helper Text"),
    options: control.textarea("Options", {
      rows: 4,
      description: 'One option per line. Format: "Label:value" or just "value".',
      placeholder: `Yes:yes
No:no`
    })
  },
  render: ({ props }) => {
    const asterisk = props.required ? raw('<span class="pb-forms-required" aria-hidden="true">*</span>') : raw("");
    const helper = props.helperText ? html`<small class="pb-forms-help">${props.helperText}</small>` : "";
    const opts = parseOptions2(String(props.options));
    const radioInputs = opts.map((o) => html`<label class="pb-forms-radio-label">
    <input class="pb-forms-radio" type="radio" name="${props.name}" value="${o.value}"${raw(props.required ? " required" : "")}>
    ${o.label}
  </label>`).join(`
  `);
    return {
      html: html`<fieldset class="pb-forms-field pb-forms-fieldset">
  <legend class="pb-forms-label">${props.label}${asterisk}</legend>
  ${raw(radioInputs)}
  ${raw(helper)}
</fieldset>`,
      css: `
.pb-forms-fieldset{border:none;padding:0;margin:0;}
.pb-forms-fieldset legend.pb-forms-label{padding:0;margin-bottom:6px;}
.pb-forms-radio-label{display:flex;align-items:center;gap:8px;font-size:0.9375rem;cursor:pointer;margin-bottom:6px;}
.pb-forms-radio{width:15px;height:15px;flex-shrink:0;}
`
    };
  }
});

// examples/plugins/forms-builder/modules/input.ts
var input_default = defineModule({
  id: "pagebuilder.forms.input",
  name: "Text Input",
  description: "Single-line input field (text, email, URL, tel, number).",
  category: "Forms",
  htmlTag: "div",
  canHaveChildren: false,
  defaults: {
    name: "field",
    label: "Label",
    placeholder: "",
    required: false,
    helperText: "",
    inputType: "text"
  },
  schema: {
    name: control.text("Field Name", {
      placeholder: "field_name",
      description: "HTML name attribute — must be unique within the form."
    }),
    label: control.text("Label"),
    placeholder: control.text("Placeholder"),
    required: control.toggle("Required"),
    helperText: control.text("Helper Text"),
    inputType: control.select("Input Type", [
      { label: "Text", value: "text" },
      { label: "Email", value: "email" },
      { label: "URL", value: "url" },
      { label: "Phone", value: "tel" },
      { label: "Number", value: "number" }
    ])
  },
  render: ({ props }) => {
    const requiredAttr = props.required ? " required" : "";
    const placeholderAttr = props.placeholder ? ` placeholder="${props.placeholder}"` : "";
    const asterisk = props.required ? raw('<span class="pb-forms-required" aria-hidden="true">*</span>') : raw("");
    const helper = props.helperText ? html`<small class="pb-forms-help">${props.helperText}</small>` : "";
    return {
      html: html`<div class="pb-forms-field">
  <label class="pb-forms-label" for="pb-${props.name}">${props.label}${asterisk}</label>
  <input
    class="pb-forms-control"
    id="pb-${props.name}"
    type="${props.inputType}"
    name="${props.name}"${raw(placeholderAttr)}${raw(requiredAttr)}
  >
  ${raw(helper)}
</div>`
    };
  }
});

// examples/plugins/forms-builder/modules/form.ts
var SUBMIT_PATH = "/admin/api/cms/plugins/pagebuilder.forms/runtime/submit";
var form_default = defineModule({
  id: "pagebuilder.forms.form",
  name: "Form",
  description: "A form container. Drop input fields inside and configure the submission target.",
  category: "Forms",
  htmlTag: "form",
  canHaveChildren: true,
  defaults: {
    formId: "",
    formName: "Contact Form",
    successMessage: "Thanks! We got your message.",
    redirectUrl: ""
  },
  schema: {
    formId: control.text("Form ID", {
      placeholder: "contact",
      description: "Unique slug that identifies this form in the submissions list."
    }),
    formName: control.text("Form Name", {
      placeholder: "Contact Form",
      description: "Human-readable label shown in the admin dashboard."
    }),
    successMessage: control.text("Success Message", {
      placeholder: "Thanks! We got your message.",
      description: "Shown (or returned) after a successful submission when no redirect URL is set."
    }),
    redirectUrl: control.url("Redirect URL", {
      description: "Optional. If set, visitors are redirected here after a successful submission."
    })
  },
  render: ({ props, children }) => {
    const action = SUBMIT_PATH;
    const redirectAttr = props.redirectUrl ? ` data-redirect="${safeUrl(props.redirectUrl)}"` : "";
    const submitScript = `(function(){
  var form = document.currentScript && document.currentScript.previousElementSibling;
  if (!form || form.dataset.pbFormsBound === '1') return;
  form.dataset.pbFormsBound = '1';
  form.addEventListener('submit', function (e) {
    e.preventDefault();
    var submitBtn = form.querySelector('button[type=submit], input[type=submit]');
    if (submitBtn) { submitBtn.disabled = true; }
    var prevStatus = form.querySelector('.pb-forms-status');
    if (prevStatus) prevStatus.remove();
    var body = {};
    var fd = new FormData(form);
    fd.forEach(function (v, k) { body[k] = typeof v === 'string' ? v : ''; });
    fetch(form.action, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
      body: JSON.stringify(body),
      credentials: 'same-origin',
    }).then(function (res) {
      return res.json().catch(function () { return { ok: res.ok }; }).then(function (data) { return { res: res, data: data }; });
    }).then(function (r) {
      var ok = r.res.ok && (r.data.ok !== false);
      var redirect = form.dataset.redirect;
      if (ok && redirect) { window.location.assign(redirect); return; }
      var msg = ok
        ? (form.dataset.successMessage || (r.data.message || 'Thanks!'))
        : ((r.data && r.data.error) || 'Sorry — something went wrong. Please try again.');
      var node = document.createElement('div');
      node.className = 'pb-forms-status pb-forms-status--' + (ok ? 'success' : 'error');
      node.setAttribute('role', ok ? 'status' : 'alert');
      node.textContent = msg;
      form.appendChild(node);
      if (ok) { form.reset(); }
    }).catch(function () {
      var node = document.createElement('div');
      node.className = 'pb-forms-status pb-forms-status--error';
      node.setAttribute('role', 'alert');
      node.textContent = 'Network error. Please try again.';
      form.appendChild(node);
    }).finally(function () {
      if (submitBtn) { submitBtn.disabled = false; }
    });
  });
})();`;
    return {
      html: html`<form
  class="pb-forms-form"
  method="post"
  action="${action}"
  data-success-message="${props.successMessage}"${raw(redirectAttr)}
>
  <input type="hidden" name="_form_id" value="${props.formId}">
  ${raw(children.join(`
`))}
</form>
<script>${raw(submitScript)}</script>`,
      css: `
.pb-forms-form{display:flex;flex-direction:column;gap:16px;}
.pb-forms-field{display:flex;flex-direction:column;gap:6px;margin-bottom:0;}
.pb-forms-label{font-size:0.875rem;font-weight:500;color:inherit;}
.pb-forms-label .pb-forms-required{color:#c0392b;margin-left:2px;}
.pb-forms-control{width:100%;padding:8px 12px;border:1px solid #d0d0d0;border-radius:4px;font-family:inherit;font-size:0.9375rem;background:#fff;color:inherit;box-sizing:border-box;}
.pb-forms-control:focus{outline:2px solid #4a90e2;outline-offset:1px;border-color:transparent;}
.pb-forms-help{font-size:0.8125rem;color:#666;}
textarea.pb-forms-control{resize:vertical;min-height:80px;}
select.pb-forms-control{appearance:auto;}
.pb-forms-status{margin-top:12px;padding:10px 14px;border-radius:4px;font-size:0.9rem;}
.pb-forms-status--success{background:#f0faf4;border:1px solid #81c9a0;color:#1a6636;}
.pb-forms-status--error{background:#fff5f5;border:1px solid #f0a0a0;color:#7b1414;}
`
    };
  }
});

// examples/plugins/forms-builder/modules/textarea.ts
var textarea_default = defineModule({
  id: "pagebuilder.forms.textarea",
  name: "Textarea",
  description: "Multi-line text area field.",
  category: "Forms",
  htmlTag: "div",
  canHaveChildren: false,
  defaults: {
    name: "message",
    label: "Message",
    placeholder: "",
    required: false,
    helperText: "",
    rows: 4
  },
  schema: {
    name: control.text("Field Name", {
      placeholder: "message",
      description: "HTML name attribute — must be unique within the form."
    }),
    label: control.text("Label"),
    placeholder: control.text("Placeholder"),
    required: control.toggle("Required"),
    helperText: control.text("Helper Text"),
    rows: control.number("Rows", { min: 2, max: 20, step: 1 })
  },
  render: ({ props }) => {
    const requiredAttr = props.required ? " required" : "";
    const placeholderAttr = props.placeholder ? ` placeholder="${props.placeholder}"` : "";
    const asterisk = props.required ? raw('<span class="pb-forms-required" aria-hidden="true">*</span>') : raw("");
    const helper = props.helperText ? html`<small class="pb-forms-help">${props.helperText}</small>` : "";
    return {
      html: html`<div class="pb-forms-field">
  <label class="pb-forms-label" for="pb-${props.name}">${props.label}${asterisk}</label>
  <textarea
    class="pb-forms-control"
    id="pb-${props.name}"
    name="${props.name}"
    rows="${props.rows}"${raw(placeholderAttr)}${raw(requiredAttr)}
  ></textarea>
  ${raw(helper)}
</div>`
    };
  }
});

// examples/plugins/forms-builder/modules/submit.ts
var submit_default = defineModule({
  id: "pagebuilder.forms.submit",
  name: "Submit Button",
  description: "Submit button for a form.",
  category: "Forms",
  htmlTag: "div",
  canHaveChildren: false,
  defaults: {
    label: "Submit"
  },
  schema: {
    label: control.text("Button Label", { placeholder: "Submit" })
  },
  render: ({ props }) => ({
    html: html`<div class="pb-forms-submit-wrap">
  <button class="pb-forms-submit" type="submit">${props.label}</button>
</div>`,
    css: `
.pb-forms-submit-wrap{display:flex;}
.pb-forms-submit{display:inline-flex;align-items:center;justify-content:center;padding:10px 24px;background:#111;color:#fff;border:none;border-radius:4px;font-size:0.9375rem;font-family:inherit;font-weight:500;cursor:pointer;transition:opacity 0.15s;}
.pb-forms-submit:hover{opacity:0.85;}
.pb-forms-submit:disabled{opacity:0.5;cursor:not-allowed;}
`
  })
});

// examples/plugins/forms-builder/__modules-facade.ts
var __modules_facade_default = [checkbox_default, honeypot_default, select_default, radio_default, input_default, form_default, textarea_default, submit_default];
export {
  __modules_facade_default as default
};
