// src/core/plugin-sdk/capabilities.ts
var PLUGIN_CAPABILITIES = [
  {
    permission: "admin.navigation",
    label: "Add pages to the admin navigation",
    description: "Allows the plugin to add pages to the CMS admin sidebar and plugin page router.",
    risk: "low",
    surfaces: ["manifest", "admin"]
  },
  {
    permission: "cms.storage",
    label: "Read and write plugin backend storage",
    description: "Allows the plugin to read and write records in resources declared by its manifest.",
    risk: "medium",
    surfaces: ["admin", "editor", "server", "cms"]
  },
  {
    permission: "cms.routes",
    label: "Register backend CMS routes",
    description: "Allows the plugin server entrypoint to register authenticated backend routes.",
    risk: "high",
    surfaces: ["server", "cms"]
  },
  {
    permission: "cms.hooks",
    label: "Subscribe to CMS lifecycle events and filters",
    description: "Allows the plugin server entrypoint to listen to CMS events (publish, content changes, page updates) and to register filters that transform values before they leave the CMS.",
    risk: "high",
    surfaces: ["server", "cms"]
  },
  {
    permission: "editor.toolbar",
    label: "Add controls to the editor toolbar",
    description: "Allows the plugin editor entrypoint to add toolbar buttons.",
    risk: "medium",
    surfaces: ["editor"]
  },
  {
    permission: "editor.commands",
    label: "Register editor commands",
    description: "Allows the plugin editor entrypoint to register commands that can be invoked by editor UI. Also grants registration of Command Spotlight palette commands (api.editor.palette.registerCommand) and live-search providers (api.editor.palette.registerProvider).",
    risk: "medium",
    surfaces: ["editor"]
  },
  {
    permission: "editor.store.read",
    label: "Read editor state",
    description: "Allows the plugin to inspect the current editor store state.",
    risk: "medium",
    surfaces: ["editor"]
  },
  {
    permission: "editor.store.write",
    label: "Modify editor state",
    description: "Allows the plugin to mutate editor store state through a host transaction.",
    risk: "high",
    surfaces: ["editor"]
  },
  {
    permission: "editor.canvas",
    label: "Add canvas overlays",
    description: "Allows the plugin to register canvas overlay React components — annotation pins, custom selection adornments, measurement tools — that mount on top of the rendered canvas via `editor.canvas.registerOverlay`.",
    risk: "high",
    surfaces: ["editor"]
  },
  {
    permission: "editor.panels",
    label: "Add editor panels",
    description: "Allows the plugin to register panels that mount in the editor's left sidebar (custom inspectors, plugin dashboards, review queues).",
    risk: "medium",
    surfaces: ["editor"]
  },
  {
    permission: "modules.register",
    label: "Register page builder modules",
    description: "Allows the plugin to ship new modules that show up in the canvas module library.",
    risk: "high",
    surfaces: ["editor", "manifest"]
  },
  {
    permission: "loops.register",
    label: "Register loop entity sources",
    description: "Allows the plugin to register data sources for the base.loop module (e.g. external collections, custom queries).",
    risk: "medium",
    surfaces: ["editor", "server", "manifest"]
  },
  {
    permission: "visualComponents.register",
    label: "Install Visual Components / templates into the site",
    description: "Allows the plugin to ship Visual Components, page templates, and class packs that are imported into the user's site on activation.",
    risk: "medium",
    surfaces: ["admin", "manifest"]
  },
  {
    permission: "dashboard.widgets.register",
    label: "Register dashboard widgets",
    description: "Allows the plugin to add cards to the admin dashboard grid (e.g. analytics charts, queue counters, plugin-specific stats). Each widget runs as a regular React component inside the host's admin shell.",
    risk: "medium",
    surfaces: ["admin"]
  },
  {
    permission: "frontend.scripts",
    label: "Inject scripts into published pages",
    description: "Allows the plugin to ship a JavaScript file that is loaded on every published page (analytics, third-party widgets, custom runtimes).",
    risk: "high",
    surfaces: ["frontend", "manifest"]
  },
  {
    permission: "frontend.tracker",
    label: "Receive frontend analytics events",
    description: "Allows the plugin to receive structured tracker events from published pages and store them in plugin-owned storage.",
    risk: "medium",
    surfaces: ["frontend", "server", "manifest"]
  },
  {
    permission: "cms.schedule",
    label: "Register scheduled jobs",
    description: "Allows the plugin to register handlers that fire on a cadence (hourly / daily / weekly / monthly / every-N-minutes). Each handler runs inside the QuickJS sandbox with a per-fire wall-clock budget; the host scheduler tick drives dispatch and records run history.",
    risk: "high",
    surfaces: ["server"]
  },
  {
    permission: "media.storage.adapter",
    label: "Provide a media storage backend",
    description: "Allows the plugin to register an exclusive storage adapter that the host elects per asset role (original / variant / avatar / font). The adapter issues signed upload targets; the host streams bytes directly. Required for S3, R2, GCS, Azure, and similar backends.",
    risk: "dangerous",
    surfaces: ["server", "cms"]
  },
  {
    permission: "media.url.transform",
    label: "Rewrite media URLs at render time",
    description: "Allows the plugin to register a pure URL transformer applied to every media path (originals + responsive variants) in the publisher, editor preview, and admin media library. Typical use: passive CDN URL prefixing.",
    risk: "medium",
    surfaces: ["server", "cms"]
  },
  {
    permission: "media.variant.delegate",
    label: "Delegate responsive variant generation to an external service",
    description: "Allows the plugin to replace the host's local image-variant ladder with a URL template (image-transform CDNs — Cloudflare Images, Imgix, Bunny Optimizer). Only one such plugin can win per host.",
    risk: "high",
    surfaces: ["server", "cms"]
  },
  {
    permission: "unstable.internals",
    label: "Use unstable internal APIs",
    description: "Reserved for trusted first-party plugins that need unstable host internals.",
    risk: "dangerous",
    surfaces: ["admin", "editor", "server", "cms"]
  }
];
var capabilityByPermission = new Map(PLUGIN_CAPABILITIES.map((capability) => [capability.permission, capability]));
// src/core/plugin-sdk/builders/defineModule.ts
function defineModule(config) {
  if (typeof config.id !== "string" || !config.id.includes(".")) {
    throw new Error(`[plugin-sdk] Module id "${config.id}" must be namespaced as "<pluginId>.<name>".`);
  }
  return {
    id: config.id,
    name: config.name,
    description: config.description,
    category: config.category,
    version: config.version ?? "1.0.0",
    defaults: config.defaults,
    schema: config.schema,
    canHaveChildren: config.canHaveChildren,
    htmlTag: config.htmlTag,
    ...config.dependencies ? { dependencies: config.dependencies } : {},
    ...config.editorRuntime ? { editorRuntime: config.editorRuntime } : {},
    render: (props, children) => config.render({ props, children }),
    ...config.preview ? { preview: (props, children) => config.preview({ props, children }) } : {}
  };
}
// src/core/plugin-sdk/builders/controls.ts
var control = {
  text(label, options = {}) {
    return { type: "text", label, ...options };
  },
  textarea(label, options = {}) {
    return { type: "textarea", label, ...options };
  },
  number(label, options = {}) {
    return { type: "number", label, ...options };
  },
  color(label, options = {}) {
    return { type: "color", label, ...options };
  },
  select(label, optionsOrOptionsList) {
    const list = Array.isArray(optionsOrOptionsList) ? optionsOrOptionsList : optionsOrOptionsList.options;
    const description = Array.isArray(optionsOrOptionsList) ? undefined : optionsOrOptionsList.description;
    return { type: "select", label, options: list, ...description ? { description } : {} };
  },
  toggle(label, options = {}) {
    return { type: "toggle", label, ...options };
  },
  image(label, options = {}) {
    return { type: "image", label, ...options };
  },
  url(label, options = {}) {
    return { type: "url", label, ...options };
  }
};
// src/core/plugin-sdk/builders/html.ts
var HTML_ESCAPE_RE = /[&<>"']/g;
var HTML_ESCAPE_MAP = {
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  '"': "&quot;",
  "'": "&#39;"
};
function escapeHtml(value) {
  return value.replace(HTML_ESCAPE_RE, (ch) => HTML_ESCAPE_MAP[ch]);
}
var RAW_BRAND = Symbol.for("@pagebuilder/plugin-sdk/raw");
function isRawHtml(value) {
  return Boolean(value) && typeof value === "object" && value[RAW_BRAND] === true;
}
function renderInterpolation(value) {
  if (value === null || value === undefined)
    return "";
  if (typeof value === "string")
    return escapeHtml(value);
  if (typeof value === "number" || typeof value === "boolean")
    return String(value);
  if (isRawHtml(value))
    return value.value;
  if (Array.isArray(value))
    return value.map(renderInterpolation).join("");
  console.warn("[plugin-sdk:html] Unsupported interpolation type", typeof value, value);
  return escapeHtml(String(value));
}
function html(strings, ...values) {
  let out = "";
  for (let i = 0;i < strings.length; i++) {
    out += strings[i];
    if (i < values.length)
      out += renderInterpolation(values[i]);
  }
  return out;
}
function safeUrl(value) {
  const s = String(value ?? "");
  if (/^javascript:/i.test(s) || /^vbscript:/i.test(s))
    return "#";
  return s;
}
// examples/plugins/newsletter/modules/preferencesLink.ts
var PLUGIN_ID = "pagebuilder.newsletter";
var preferencesLink_default = defineModule({
  id: `${PLUGIN_ID}.preferences-link`,
  name: "Preferences Link",
  description: "Renders a {{preferences_url}} placeholder anchor for use inside broadcast email bodies. Substituted with the subscriber's manage-preferences URL at send time.",
  category: "Newsletter",
  htmlTag: "span",
  version: "0.1.0",
  defaults: {
    label: "Manage email preferences"
  },
  schema: {
    label: control.text("Link label")
  },
  render: ({ props }) => {
    return {
      html: html`
        <a class="nl-pref-link" href="{{preferences_url}}">${props.label}</a>
      `,
      css: `
        .nl-pref-link { color: inherit; text-decoration: underline; }
        .nl-pref-link:hover { opacity: 0.75; }
      `
    };
  }
});

// examples/plugins/newsletter/modules/subscribeForm.ts
var PLUGIN_ID2 = "pagebuilder.newsletter";
var SUBSCRIBE_PATH = `/admin/api/cms/plugins/${PLUGIN_ID2}/runtime/subscribe`;
var subscribeForm_default = defineModule({
  id: `${PLUGIN_ID2}.subscribe-form`,
  name: "Newsletter Subscribe Form",
  description: "Email subscribe form — submits to the Newsletter plugin's public /subscribe endpoint.",
  category: "Newsletter",
  htmlTag: "section",
  version: "0.1.0",
  defaults: {
    listIds: "",
    successMessage: "Thank you for subscribing!",
    consentLabel: "I agree to receive email newsletters.",
    submitLabel: "Subscribe",
    emailPlaceholder: "your@email.com",
    namePlaceholder: "Your name (optional)",
    showNameField: false,
    successUrl: "/"
  },
  schema: {
    listIds: control.text("List IDs", {
      placeholder: "id1,id2",
      description: "Comma-separated list IDs to subscribe to. Leave blank to use the default list."
    }),
    successUrl: control.url("Success URL", {
      description: "Page to redirect to after a successful subscription."
    }),
    successMessage: control.text("Success message", {
      description: "Shown on the server confirmation page (if no success URL redirect is set)."
    }),
    consentLabel: control.text("Consent label"),
    submitLabel: control.text("Submit button label"),
    emailPlaceholder: control.text("Email placeholder"),
    namePlaceholder: control.text("Name placeholder"),
    showNameField: control.toggle("Show name field")
  },
  render: ({ props }) => {
    const action = safeUrl(SUBSCRIBE_PATH);
    const listIdsValue = String(props.listIds ?? "").trim();
    const nameField = props.showNameField ? html`<div class="nl-subscribe__field">
          <label class="nl-subscribe__label" for="nl-name">${props.namePlaceholder}</label>
          <input
            class="nl-subscribe__input"
            type="text"
            id="nl-name"
            name="name"
            placeholder="${props.namePlaceholder}"
            autocomplete="name"
          />
        </div>` : "";
    const listIdsField = listIdsValue ? html`<input type="hidden" name="listIds" value="${listIdsValue}" />` : "";
    return {
      html: html`
        <section class="nl-subscribe">
          <form class="nl-subscribe__form" method="GET" action="${action}" novalidate>
            <div class="nl-subscribe__field">
              <label class="nl-subscribe__label" for="nl-email">${props.emailPlaceholder}</label>
              <input
                class="nl-subscribe__input"
                type="email"
                id="nl-email"
                name="email"
                placeholder="${props.emailPlaceholder}"
                autocomplete="email"
                required
              />
            </div>
            ${nameField}
            <div class="nl-subscribe__consent">
              <label class="nl-subscribe__consent-label">
                <input type="checkbox" name="consent" value="true" required />
                <span>${props.consentLabel}</span>
              </label>
            </div>
            ${listIdsField}
            <input type="hidden" name="redirect" value="${safeUrl(String(props.successUrl ?? "/"))}" />
            <button class="nl-subscribe__btn" type="submit">
              ${props.submitLabel}
            </button>
          </form>
        </section>
      `,
      css: `
        .nl-subscribe { max-width: 480px; margin: 0 auto; padding: 32px 16px; font-family: inherit; }
        .nl-subscribe__form { display: flex; flex-direction: column; gap: 12px; }
        .nl-subscribe__field { display: flex; flex-direction: column; gap: 4px; }
        .nl-subscribe__label { font-size: 0.875rem; color: #555; }
        .nl-subscribe__input {
          padding: 10px 14px;
          border: 1px solid #ccc;
          border-radius: 6px;
          font-size: 1rem;
          font-family: inherit;
          width: 100%;
          box-sizing: border-box;
        }
        .nl-subscribe__input:focus { outline: 2px solid #111; outline-offset: 2px; }
        .nl-subscribe__consent { font-size: 0.875rem; color: #555; }
        .nl-subscribe__consent-label { display: flex; align-items: flex-start; gap: 8px; cursor: pointer; }
        .nl-subscribe__btn {
          padding: 12px 24px;
          background: #111;
          color: #fff;
          border: none;
          border-radius: 6px;
          font-size: 1rem;
          font-family: inherit;
          font-weight: 600;
          cursor: pointer;
          align-self: flex-start;
        }
        .nl-subscribe__btn:hover { background: #333; }
        .nl-subscribe__btn:focus { outline: 2px solid #111; outline-offset: 2px; }
      `
    };
  }
});

// examples/plugins/newsletter/__modules-facade.ts
var __modules_facade_default = [preferencesLink_default, subscribeForm_default];
export {
  __modules_facade_default as default
};
