// examples/plugins/analytics/frontend/tracker.ts
var PLUGIN_ID = "pagebuilder.analytics";
var GEO_CACHE_KEY = "__pb_analytics_geo";
var ADMIN_CACHE_KEY = "__pb_analytics_admin";
var OPT_OUT_KEY = "__pb_analytics_optout";
var ROUTE_BASE = "/admin/api/cms/plugins/pagebuilder.analytics/runtime";
(function init() {
  const dnt = typeof navigator !== "undefined" && navigator.doNotTrack === "1" || typeof window !== "undefined" && window.doNotTrack === "1";
  if (dnt)
    return;
  try {
    if (localStorage.getItem(OPT_OUT_KEY) === "1")
      return;
  } catch {}
  const pb = window.__pb;
  if (!pb?.tracker) {
    console.warn("[analytics] page runtime not available");
    return;
  }
  let cachedCountry = "";
  try {
    cachedCountry = sessionStorage.getItem(GEO_CACHE_KEY) ?? "";
  } catch {}
  function fetchCountry() {
    if (cachedCountry)
      return;
    fetch(`${ROUTE_BASE}/geo`, { method: "GET", credentials: "omit" }).then((r) => r.json()).then((data) => {
      const country = typeof data.country === "string" ? data.country : "";
      cachedCountry = country;
      try {
        sessionStorage.setItem(GEO_CACHE_KEY, country);
      } catch {}
    }).catch(() => {});
  }
  let cachedIsAdmin = false;
  let adminCheckResolved = false;
  try {
    const cached = sessionStorage.getItem(ADMIN_CACHE_KEY);
    if (cached !== null) {
      cachedIsAdmin = cached === "1";
      adminCheckResolved = true;
    }
  } catch {}
  function fetchIsAdmin() {
    if (adminCheckResolved)
      return;
    fetch(`${ROUTE_BASE}/is-admin`, { method: "GET", credentials: "include" }).then((r) => r.json()).then((data) => {
      cachedIsAdmin = data.admin === true;
      adminCheckResolved = true;
      try {
        sessionStorage.setItem(ADMIN_CACHE_KEY, cachedIsAdmin ? "1" : "0");
      } catch {}
    }).catch(() => {
      cachedIsAdmin = false;
      adminCheckResolved = true;
    });
  }
  fetchCountry();
  fetchIsAdmin();
  const ua = typeof navigator !== "undefined" ? navigator.userAgent : "";
  function payload(extra = {}) {
    return {
      country: cachedCountry,
      userAgent: ua,
      isAdmin: cachedIsAdmin,
      ...extra
    };
  }
  let pageStartTime = Date.now();
  let interactionCount = 0;
  function bumpInteraction() {
    interactionCount++;
  }
  document.addEventListener("click", bumpInteraction, { passive: true, capture: true });
  document.addEventListener("keypress", bumpInteraction, { passive: true, capture: true });
  document.addEventListener("scroll", bumpInteraction, { passive: true, capture: true, once: true });
  pb.hooks.on("page-view", (detail) => {
    pageStartTime = Date.now();
    interactionCount = 0;
    pb.tracker.sendFor(PLUGIN_ID, "page-view", payload({
      path: detail.path,
      title: detail.title,
      referrer: document.referrer
    }));
  });
  pb.hooks.on("link-click", (detail) => {
    const href = typeof detail.href === "string" ? detail.href : "";
    let outbound = false;
    try {
      outbound = href.startsWith("http") && new URL(href).hostname !== location.hostname;
    } catch {}
    pb.tracker.sendFor(PLUGIN_ID, "link-click", payload({ href, text: detail.text, outbound }));
  });
  pb.hooks.on("scroll-depth", (detail) => {
    pb.tracker.sendFor(PLUGIN_ID, "scroll-depth", payload({ depth: detail.depth, path: location.pathname }));
  });
  const vitals = { lcp: null, cls: 0, fid: null };
  function observeVitals() {
    if (typeof PerformanceObserver === "undefined")
      return;
    try {
      const lcpObs = new PerformanceObserver((list) => {
        const entries = list.getEntries();
        const last = entries[entries.length - 1];
        if (last)
          vitals.lcp = Math.round(last.startTime);
      });
      lcpObs.observe({ type: "largest-contentful-paint", buffered: true });
    } catch {}
    try {
      const clsObs = new PerformanceObserver((list) => {
        for (const entry of list.getEntries()) {
          const e = entry;
          if (!e.hadRecentInput && typeof e.value === "number")
            vitals.cls += e.value;
        }
      });
      clsObs.observe({ type: "layout-shift", buffered: true });
    } catch {}
    try {
      const fidObs = new PerformanceObserver((list) => {
        const first = list.getEntries()[0];
        if (first && vitals.fid === null && first.processingStart !== undefined) {
          vitals.fid = Math.round(first.processingStart - first.startTime);
        }
      });
      fidObs.observe({ type: "first-input", buffered: true });
    } catch {}
  }
  observeVitals();
  function flushVitals() {
    if (vitals.lcp === null && vitals.cls === 0 && vitals.fid === null)
      return;
    pb.tracker.sendFor(PLUGIN_ID, "web-vitals", payload({
      lcp: vitals.lcp,
      cls: Math.round(vitals.cls * 1000) / 1000,
      fid: vitals.fid,
      path: location.pathname
    }));
  }
  function flushBounce() {
    if (interactionCount === 0 && Date.now() - pageStartTime < 1e4) {
      pb.tracker.sendFor(PLUGIN_ID, "bounce", payload({ path: location.pathname }));
    }
  }
  function onPageHide() {
    flushVitals();
    flushBounce();
  }
  window.addEventListener("pagehide", onPageHide, { capture: true, once: true });
  window.addEventListener("beforeunload", onPageHide, { capture: true, once: true });
  document.addEventListener("visibilitychange", () => {
    if (document.visibilityState === "hidden")
      flushVitals();
  });
})();
